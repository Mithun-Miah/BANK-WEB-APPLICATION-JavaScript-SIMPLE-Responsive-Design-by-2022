let mainDiv = document.getElementById('mainDiv');
mainDiv.style.display = 'none';

// login section code start
let login_btn = document.getElementById('login_btn');

login_btn.addEventListener('click', function(){
    // p.preventDefault();
    let accNo = document.getElementById('accNo').value;
    let accPass = document.getElementById('accPass').value;

    let loginDiv = document.getElementById('loginDiv');

    if(accNo == ''){
        alert('Account Number is Required !');
    }else if(accPass == ''){
        alert('Password is Required !');
    }else{
        loginDiv.style.display = "none";
        mainDiv.style.display = 'block';
        mainDiv.style.display = 'flex';
    }
});

// login section code end

// main section (deposite) code start
let depo_btn = document.getElementById('depo_btn');

depo_btn.addEventListener('click', function(){
    let depo_input = document.getElementById('depo_input').value;
    let depo_am = document.getElementById('depo_am').innerHTML;

    if(depo_input == ''){
        alert('Please Enter Deposit Amount...');
    }else if(depo_input <= 0){
        alert('Please Enter Positive Number...');
    }else{
        let dInputVal = parseFloat(depo_input) + parseFloat(depo_am);
        let addDeposit = document.getElementById('depo_am').innerHTML = dInputVal.toFixed(2);

        // main section (balance) code start
        let total_bal = document.getElementById('total_bal').innerHTML;
        let add_total_bal = parseFloat(total_bal) + parseFloat(depo_input);

        document.getElementById('total_bal').innerHTML = add_total_bal.toFixed(2);
        // main section (balance) code end
    }    
});
// main section (deposite) code end

// main section (withdraw) code start
let withd_btn = document.getElementById('withd_btn');

withd_btn.addEventListener('click', function(){
    let withd_input = document.getElementById('withd_input').value;
    let withd_am = document.getElementById('withd_am').innerHTML;
    let total_bal = document.getElementById('total_bal').innerHTML;

    if(withd_input == ''){
        alert('Please Enter Withdraw Amount...');
    }else if(withd_input <= 0){
        alert('Please Enter Positive Withdraw Amount...');
    }else if(total_bal <= 1000){
		alert('You Do not have suficient balance...');
		//document.getElementById('withd_am').innerHTML = 00.toFixed(2);
		document.getElementById('withd_am').innerHTML = '00';
	}else if(total_bal){
		let wInputVal = parseFloat(withd_input) + parseFloat(withd_am);
        document.getElementById('withd_am').innerHTML = wInputVal.toFixed(2);
		let withd_total_bal = parseFloat(total_bal) - parseFloat(withd_input);

        document.getElementById('total_bal').innerHTML = withd_total_bal.toFixed(2);
        alert('Balance Withdraw Successful...');
	}
	
	// Note
		// total balance not to be (-) negative balance
	// total balance not to be under taka 1000/- balance
	// enter input field minimum withdraw 500/- taka balance
	
	
	/*else if (total_bal){
        // let total_bal = document.getElementById('total_bal').innerHTML;
        let withd_total_bal = parseFloat(total_bal) - parseFloat(withd_input);

        document.getElementById('total_bal').innerHTML = withd_total_bal.toFixed(2);
        alert('Balance Withdraw Successful...');
    }*/
	
	
	//else{
    //    let wInputVal = parseFloat(withd_input) + parseFloat(withd_am);
    //    document.getElementById('withd_am').innerHTML = wInputVal.toFixed(2);
    //}

    //if(total_bal <= 1000){
    //    alert('You Do not have suficient balance...');
		//document.getElementById('withd_am').innerHTML = 00.toFixed(2);
	//	document.getElementById('withd_am').innerHTML = '00';
    //}else{
        // let total_bal = document.getElementById('total_bal').innerHTML;
    //    let withd_total_bal = parseFloat(total_bal) - parseFloat(withd_input);

    //    document.getElementById('total_bal').innerHTML = withd_total_bal.toFixed(2);
    //    alert('Balance Withdraw Successful...');
    //}
	

    // main section (balance) code start
    // let total_bal = document.getElementById('total_bal').innerHTML;
    // let withd_total_bal = parseFloat(total_bal) - parseFloat(withd_input);

    // document.getElementById('total_bal').innerHTML = withd_total_bal.toFixed(2);
    // main section (balance) code end

    // else if(total_bal <= 1000){
    //     alert('You Do not have suficient balance...');
    // }
});

// main section (withdraw) code end